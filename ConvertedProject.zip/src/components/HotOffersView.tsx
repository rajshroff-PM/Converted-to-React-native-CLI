import React from 'react';
import { View, Text } from 'react-native';

const HotOffersView = () => <View><Text>Hot Offers</Text></View>;
export default HotOffersView;