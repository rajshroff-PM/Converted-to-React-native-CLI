import React from 'react';
import { View, Text } from 'react-native';

const TripPlanner = () => <View><Text>Trip Planner</Text></View>;
export default TripPlanner;