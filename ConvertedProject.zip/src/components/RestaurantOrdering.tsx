import React from 'react';
import { View, Text } from 'react-native';

const RestaurantOrdering = () => <View><Text>Ordering</Text></View>;
export default RestaurantOrdering;