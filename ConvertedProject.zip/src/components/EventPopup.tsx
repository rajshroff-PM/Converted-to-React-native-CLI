import React from 'react';
import { View, Text } from 'react-native';

const EventPopup = () => <View><Text>Event Popup</Text></View>;
export default EventPopup;