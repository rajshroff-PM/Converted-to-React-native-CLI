import React from 'react';
import { View, Text } from 'react-native';

const AvatarSelector = () => <View><Text>Avatar Selector</Text></View>;
export default AvatarSelector;