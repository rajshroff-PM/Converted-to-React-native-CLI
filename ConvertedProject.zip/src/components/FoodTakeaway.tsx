import React from 'react';
import { View, Text } from 'react-native';

const FoodTakeaway = () => <View><Text>Food Takeaway</Text></View>;
export default FoodTakeaway;