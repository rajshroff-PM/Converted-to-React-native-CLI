import React from 'react';
import { View, Text } from 'react-native';

const LocationSelector = () => <View><Text>Location Selector</Text></View>;
export default LocationSelector;