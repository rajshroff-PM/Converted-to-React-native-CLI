import React from 'react';
import { View, Text } from 'react-native';

const ParkingDashboard = () => <View><Text>Parking</Text></View>;
export default ParkingDashboard;