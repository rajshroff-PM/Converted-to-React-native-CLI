import React from 'react';
import { View, Text } from 'react-native';

const RewardsView = () => <View><Text>Rewards</Text></View>;
export default RewardsView;