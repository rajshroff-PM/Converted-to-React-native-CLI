import React from 'react';
import { View, Text } from 'react-native';

const NavigationGame = () => <View><Text>Game</Text></View>;
export default NavigationGame;