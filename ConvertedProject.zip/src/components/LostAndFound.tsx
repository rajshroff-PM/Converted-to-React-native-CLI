import React from 'react';
import { View, Text } from 'react-native';

const LostAndFound = () => <View><Text>Lost & Found</Text></View>;
export default LostAndFound;