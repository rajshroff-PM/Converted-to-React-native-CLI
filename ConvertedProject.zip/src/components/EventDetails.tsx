import React from 'react';
import { View, Text } from 'react-native';

const EventDetails = () => <View><Text>Event Details</Text></View>;
export default EventDetails;