import React from 'react';
import { View, Text } from 'react-native';

const BlogView = () => <View><Text>Blog</Text></View>;
export default BlogView;