import React from 'react';
import { View, Text } from 'react-native';

const EventsView = () => <View><Text>Events</Text></View>;
export default EventsView;