import React from 'react';
import { View, Text } from 'react-native';

const LaunchScreen = () => <View><Text>Launch Screen</Text></View>;
export default LaunchScreen;