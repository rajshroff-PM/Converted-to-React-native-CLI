import React from 'react';
import { View, Text } from 'react-native';

const LocationSharing = () => <View><Text>Location Sharing</Text></View>;
export default LocationSharing;