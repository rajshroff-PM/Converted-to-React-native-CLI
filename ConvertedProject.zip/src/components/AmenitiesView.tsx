import React from 'react';
import { View, Text } from 'react-native';

const AmenitiesView = () => <View><Text>Amenities</Text></View>;
export default AmenitiesView;